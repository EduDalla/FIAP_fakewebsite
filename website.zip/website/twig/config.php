<?php

require_once "database.php";

$url_base = "http://localhost/website/twig/";

